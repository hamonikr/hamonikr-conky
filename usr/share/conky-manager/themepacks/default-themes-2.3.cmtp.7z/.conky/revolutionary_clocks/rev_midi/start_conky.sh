#!/bin/bash

sleep 5
conky -c $HOME/.Conky/revolutionary_clocks/rev_midi/conkyrc &
exit 0

