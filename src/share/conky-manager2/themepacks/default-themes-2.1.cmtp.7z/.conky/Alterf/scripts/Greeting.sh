#!/bin/bash
#
# ----------------------------------------------------------------------------------
# Variable
Greeting=$(date +%H)
LANGUAGE=$(echo $LANG | cut -d'_' -f1)

# Main Command
if [ "$LANGUAGE" = "ko" ]; then
    cat $0 | grep "$Greeting" | sed 's/# '$Greeting' //; s/\/.*//'
else
    cat $0 | grep "$Greeting" | sed 's/# '$Greeting' //; s/.*\///'
fi

# --------------------------------------------------------------------------------
# 00 안녕하세요, 자정입니다 / Good Midnight
# 01 좋은 아침입니다 / Good Morning
# 02 좋은 아침입니다 / Good Morning
# 03 좋은 아침입니다 / Good Morning
# 04 좋은 아침입니다 / Good Morning
# 05 좋은 아침입니다 / Good Morning
# 06 좋은 아침입니다 / Good Morning
# 07 좋은 아침입니다 / Good Morning
# 08 좋은 아침입니다 / Good Morning
# 09 좋은 아침입니다 / Good Morning
# 10 좋은 아침입니다 / Good Morning
# 11 좋은 하루 되세요 / Good Day
# 12 좋은 하루 되세요 / Good Day
# 13 좋은 오후입니다 / Good Afternoon
# 14 좋은 오후입니다 / Good Afternoon
# 15 좋은 오후입니다 / Good Afternoon
# 16 좋은 오후입니다 / Good Afternoon
# 17 좋은 오후입니다 / Good Afternoon
# 18 좋은 저녁입니다 / Good Evening
# 19 좋은 저녁입니다 / Good Evening
# 20 좋은 저녁입니다 / Good Evening
# 21 좋은 저녁입니다 / Good Evening
# 22 좋은 저녁입니다 / Good Evening
# 23 좋은 저녁입니다 / Good Evening

