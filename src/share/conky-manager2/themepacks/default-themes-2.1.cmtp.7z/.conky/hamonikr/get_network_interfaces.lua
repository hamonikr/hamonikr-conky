function get_network_interface(type)
    local handle = io.popen("ip -o link show | awk '/state UP/ {print $2}' | sed 's/://' | grep -E '^(eth|en|enx|wlan|wl|wlp)'")
    local result = handle:read("*a")
    handle:close()
    
    -- 디버깅: 명령어 출력 결과 확인
    print("Command Output:")
    print(result)
    
    for interface in result:gmatch("%S+") do
        -- 문자열의 앞뒤 공백 제거
        interface = interface:match("^%s*(.-)%s*$")
        
        -- 디버깅: 각 인터페이스 이름 출력
        print("Interface Found:", interface)
        
        if type == "wired" and (interface:match("^eth") or interface:match("^enx") or interface:match("^en")) then
            print("Classified as Wired:", interface)
            return interface
        elseif type == "wireless" and (interface:match("^wlan") or interface:match("^wl") or interface:match("^wlp")) then
            print("Classified as Wireless:", interface)
            return interface
        end
    end
    
    return nil
end

function conky_network_interface_wired()
    local wired_interface = get_network_interface("wired")
    return wired_interface or "No wired interface"
end

function conky_network_interface_wireless()
    local wireless_interface = get_network_interface("wireless")
    return wireless_interface or "No wireless interface"
end

-- 디버깅: Conky 함수 호출 결과 확인
print("Wired Interface:", conky_network_interface_wired())
print("Wireless Interface:", conky_network_interface_wireless())
